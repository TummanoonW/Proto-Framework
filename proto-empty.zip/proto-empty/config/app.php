<?php
    class App{
        public static $name = "Proto-Framework";
        public static $framework = "Proto-Framework";
        public static $version = "4.2";
        public static $lastUpdate = "2019/07/28 23:00:00";
        public static $platform = ["PHP", "HTML", "JS", "CSS", "Front-End"]; 


        /* --- Web Page file names --- */
        public static $pageAbout = "about.php";
        /* --- Web Page file names --- */


        /* --- Web Route file names --- */

        /* --- Web Route file names --- */


        /* --- API file names --- */

        /* --- API file names --- */

    }
?>